import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class EinstensEquation {

	private JFrame frame;
	private JTextField txtMass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EinstensEquation window = new EinstensEquation();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EinstensEquation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(153, 0, 51));
		frame.setBounds(100, 100, 457, 317);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnCalculate = new JButton("Calculate the energy");
		
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
				
				//declare local variables and constants
				double mass;
				final double speed_light = 2.998 * Math.pow(10, 8);
				
				//get the mass from the user
				String mass_str = txtMass.getText();
				
				//convert it to a double
				mass = Double.parseDouble(mass_str);
				
				double energy = mass * Math.pow(speed_light, 2);
				
				JLabel lblAnswer = new JLabel("The answer");
				lblAnswer.setForeground(Color.WHITE);
				lblAnswer.setFont(new Font("Tahoma", Font.BOLD, 18));
				lblAnswer.setBounds(93, 208, 241, 34);
				frame.getContentPane().add(lblAnswer);

				
				
				
			}
		});
		btnCalculate.setBackground(new Color(153, 0, 51));
		btnCalculate.setForeground(new Color(153, 0, 0));
		btnCalculate.setFont(new Font("Cooper Std Black", Font.PLAIN, 18));
		btnCalculate.setBounds(93, 152, 241, 34);
		frame.getContentPane().add(btnCalculate);
		
		JLabel lblQuestion = new JLabel("Enter the mass of the object:");
		lblQuestion.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblQuestion.setForeground(new Color(255, 255, 255));
		lblQuestion.setBounds(74, 34, 299, 51);
		frame.getContentPane().add(lblQuestion);
		
		txtMass = new JTextField();
		txtMass.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtMass.setForeground(new Color(0, 0, 0));
		txtMass.setBounds(170, 96, 86, 20);
		frame.getContentPane().add(txtMass);
		txtMass.setColumns(10);
		
	}
}
